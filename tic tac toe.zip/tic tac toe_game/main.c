#include <stdio.h>

//structs
typedef struct
{
	int row;
	int column;
} position;

typedef struct
{
	char x;
	char o;
} gamePlayers;

//variables
char board[5][5] = {
	{' ', '|', ' ', '|', ' '},
	{'-', '|', '-', '|', '-'},
	{' ', '|', ' ', '|', ' '},
	{'-', '|', '-', '|', '-'},
	{' ', '|', ' ', '|', ' '}
};

int run = 1;
int playerXTurn;
int whoWasFirst;
int overideX, overideO;
char getRougeChar = ' ';
int playerOWon = 0, playerXWon = 0;
int forgivePlayerX, forgivePlayerO;
int *playerOWonPointer = &playerOWon;
int *playerXWonPointer = &playerXWon;
int *forgiveXPointer = &forgivePlayerX;
int *forgiveOPointer = &forgivePlayerO;

//pointers variables
int *xPointer = &playerXTurn;
int *whoWasFirstPointer = &whoWasFirst;

//struct variable init
gamePlayers players = {'X', 'O'};
position boardPosition;

//functions
int printBoard();
void ifPlayerXTurnPrint();
void ifPlayerXTurn();
void getInput();
void playerXPositionPlace();
void playerOPositionPlace();
void forgivePlayer();
void captureRougeChar();
void ifXWin();
void ifOWin();
void gameTie();
void ifBoardFull();

int main()
{
	printBoard();
	*xPointer = 1;
	while (run == 1)
	{
		ifPlayerXTurnPrint();
		getInput();
		ifPlayerXTurn();
		captureRougeChar();
		printBoard();
		ifXWin();
		ifOWin();
		ifBoardFull();
	}
	
	return 0;
}

void captureRougeChar()
{
	scanf("%c", &getRougeChar);
	getRougeChar = ' ';
}

int printBoard()
{
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			printf("%c", board[i][j]);
		}
		printf("\n");
	}
}

void getInput()
{
	scanf("%d %d", &boardPosition.row, &boardPosition.column);
}

void ifPlayerXTurnPrint()
{
	if (playerXTurn == 1)
	{
		printf("Player X Turn!!\n");
	}
	else if (playerXTurn == 0)
	{
		printf("Player O Turn!!\n");
	}
}

void ifPlayerXTurn()
{
	if (playerXTurn == 1)
	{
		playerXPositionPlace();
		*xPointer = 0;
		*whoWasFirstPointer = 1;
	}
	else if (playerXTurn == 0)
	{
		playerOPositionPlace();
		*xPointer = 1;
		*whoWasFirstPointer = 0;
	}
}

void forgivePlayer()
{
	if (forgivePlayerX == 1)
	{
		printBoard();
		printf("INVALID!!!\nEnter new coordinates\n");
		getInput();
		captureRougeChar();
		playerXPositionPlace();
		*forgiveXPointer = 0;
	}
	else if (forgivePlayerO == 1)
	{
		printBoard();
		printf("INVALID!!!\nEnter new coordinates\n");
		getInput();
		captureRougeChar();
		playerOPositionPlace();
		*forgiveOPointer = 0;
	}
}

void playerXPositionPlace()
{
	if (boardPosition.row == 1 && boardPosition.column == 1)
	{
		if (board[0][0] == players.o || board[0][0] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[0][0] = players.x;			
		}
	}
	else if (boardPosition.row == 1 && boardPosition.column == 2)
	{
		if (board[0][2] == players.o || board[0][2] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[0][2] = players.x;
		}
	}
	else if (boardPosition.row == 1 && boardPosition.column == 3)
	{
		if (board[0][4] == players.o || board[0][4] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[0][4] = players.x;
		}
	}
	else if (boardPosition.row == 2 && boardPosition.column == 1)
	{
		if (board[2][0] == players.o || board[2][0] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[2][0] = players.x;
		}
	}
	else if (boardPosition.row == 2 && boardPosition.column == 2)
	{
		if (board[2][2] == players.o || board[2][2] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[2][2] = players.x;
		}
	}
	else if (boardPosition.row == 2 && boardPosition.column == 3)
	{
		if (board[2][4] == players.o || board[2][4] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[2][4] = players.x;
		}
	}
	else if (boardPosition.row == 3 && boardPosition.column == 1)
	{
		if (board[4][0] == players.o || board[4][0] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[4][0] = players.x;
		}
	}
	else if (boardPosition.row == 3 && boardPosition.column == 2)
	{
		if (board[4][2] == players.o || board[4][2] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[4][2] = players.x;
		}
	}
	else if (boardPosition.row == 3 && boardPosition.column == 3)
	{
		if (board[4][4] == players.o || board[4][4] == players.x)
		{
			*forgiveXPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveXPointer = 0;
			board[4][4] = players.x;
		}
	}
	else if (playerXTurn == 1 && (boardPosition.row != 1 && boardPosition.column != 1) && (boardPosition.row != 2 && boardPosition.column != 1) && (boardPosition.row != 3 && boardPosition.column != 1) && (boardPosition.row != 1 && boardPosition.column != 2) && (boardPosition.row != 2 && boardPosition.column != 2) && (boardPosition.row != 3 && boardPosition.column != 2) && (boardPosition.row != 1 && boardPosition.column != 3) && (boardPosition.row != 2 && boardPosition.column != 3) && (boardPosition.row != 3 && boardPosition.column != 3))
	{
		*forgiveXPointer = 1;
		forgivePlayer();
	}
}

void playerOPositionPlace()
{
	if (playerXTurn == 0 && boardPosition.row == 1 && boardPosition.column == 1)
	{
		if (board[0][0] == players.o || board[0][0] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[0][0] = players.o;
		}
	}
	else if (playerXTurn == 0 && boardPosition.row == 1 && boardPosition.column == 2)
	{
		if (board[4][4] == players.o || board[4][4] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[0][2] = players.o;
		}
	}
	else if (playerXTurn == 0 && boardPosition.row == 1 && boardPosition.column == 3)
	{
		if (board[0][4] == players.o || board[0][4] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[0][4] = players.o;
		}
	}
	else if (playerXTurn == 0 && boardPosition.row == 2 && boardPosition.column == 1)
	{
		if (board[2][0] == players.o || board[2][0] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[2][0] = players.o;
		}
	}
	else if (playerXTurn == 0 && boardPosition.row == 2 && boardPosition.column == 2)
	{
		if (board[2][2] == players.o || board[2][2] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[2][2] = players.o;
		}
	}
	else if (playerXTurn == 0 && boardPosition.row == 2 && boardPosition.column == 3)
	{
		if (board[2][4] == players.o || board[2][4] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[2][4] = players.o;
		}

	}
	else if (playerXTurn == 0 && boardPosition.row == 3 && boardPosition.column == 1)
	{
		if (board[4][0] == players.o || board[4][0] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[4][0] = players.o;
		}
	}
	else if (playerXTurn == 0 && boardPosition.row == 3 && boardPosition.column == 2)
	{
		if (board[4][2] == players.o || board[4][2] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[4][2] = players.o;
		}
	}
	else if (playerXTurn == 0 && boardPosition.row == 3 && boardPosition.column == 3)
	{
		if (board[4][4] == players.o || board[4][4] == players.x)
		{
			*forgiveOPointer = 1;
			forgivePlayer();
		}
		else 
		{
			*forgiveOPointer = 0;
			board[4][4] = players.o;
		}
	}
	else if (playerXTurn == 0 && (boardPosition.row != 1 && boardPosition.column != 1) && (boardPosition.row != 2 && boardPosition.column != 1) && (boardPosition.row != 3 && boardPosition.column != 1) && (boardPosition.row != 1 && boardPosition.column != 2) && (boardPosition.row != 2 && boardPosition.column != 2) && (boardPosition.row != 3 && boardPosition.column != 2) && (boardPosition.row != 1 && boardPosition.column != 3) && (boardPosition.row != 2 && boardPosition.column != 3) && (boardPosition.row != 3 && boardPosition.column != 3))
	{
		*forgiveOPointer = 1;
		forgivePlayer();
	}
}

void ifXWin()
{
	//horizontal wins
	if (board[0][0] == players.x && board[0][2] == players.x && board[0][4] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
	else if (board[2][0] == players.x && board[2][2] == players.x && board[2][4] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
	else if (board[4][0] == players.x && board[4][2] == players.x && board[4][4] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
	//vertical wins
	else if (board[0][0] == players.x && board[2][0] == players.x && board[4][0] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
	else if (board[0][2] == players.x && board[2][2] == players.x && board[4][2] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
	else if (board[0][4] == players.x && board[2][4] == players.x && board[4][4] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
	//cross wins
	else if (board[0][4] == players.x && board[2][2] == players.x && board[4][0] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
	else if (board[0][0] == players.x && board[2][2] == players.x && board[4][4] == players.x)
	{
		printf("Player X Wins!!!\n");
		run = 0;
		*playerXWonPointer = 1;
	}
}

void ifOWin()
{
	//horizontal wins
	if (board[0][0] == players.o && board[0][2] == players.o && board[0][4] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
	else if (board[2][0] == players.o && board[2][2] == players.o && board[2][4] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
	else if (board[4][0] == players.o && board[4][2] == players.o && board[4][4] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
	//vertical wins
	else if (board[0][0] == players.o && board[2][0] == players.o && board[4][0] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
	else if (board[0][2] == players.o && board[2][2] == players.o && board[4][2] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
	else if (board[0][4] == players.o && board[2][4] == players.o && board[4][4] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
	//cross wins
	else if (board[0][4] == players.o && board[2][2] == players.o && board[4][0] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
	else if (board[0][0] == players.o && board[2][2] == players.o && board[4][4] == players.o)
	{
		printf("Player O Wins!!!\n");
		run = 0;
		*playerOWonPointer = 1;
	}
}

//this function is sadly complicated :(
void ifBoardFull()
{
	if ((board[0][0] == players.x || board[0][0] == players.o) && (board[0][2] == players.x || board[0][2] == players.o) && (board[0][4] == players.x || board[0][4] == players.o) && (board[2][0] == players.x || board[2][0] == players.o) && (board[2][2] == players.x || board[2][2] == players.o) && (board[2][4] == players.x || board[2][4] == players.o) && (board[4][0] == players.x || board[4][0] == players.o) && (board[4][2] == players.x || board[4][4] == players.o))
	{
		gameTie();
	}
}

void gameTie()
{
	if (playerOWon != 1 && playerXWon != 1)
	{
		printf("Tie!!!\n");
		run = 0;
	}
}